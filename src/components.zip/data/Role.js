export const Roles = [
  { value: "", label: "--Select--" },
  { value: "Member", label: "CoP Member" },
  { value: "National Executive Member", label: "PeWG National Executive Member" },
  { value: "Area Coordinator", label: "PeWG Area Coordinator" },
  { value: "Area Executive Member", label: "PeWG Area Executive Member" },
  { value: "District Coordinator", label: "PeWG District Coordinator" },
  { value: "District Executive Member", label: "Pewg District Executive Member" },
  { value: "Local Coordinator", label: "PeWG Local Coordinator" },
  { value: "Local Executive Member", label: "PeWG Local Executive Member" },
  { value: "Other", label: "Other" },
];
